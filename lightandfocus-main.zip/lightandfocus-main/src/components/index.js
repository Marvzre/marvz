export { default as Image1 } from './image.jsx';
export { default as ImageWrapper } from './imageWrapper.jsx';
export { default as Section2 } from './section2.jsx';
export { default as Section3 } from './section3.jsx';
export { default as Header } from './header.jsx';
export { default as Section4 } from './section4.jsx';
export { default as Section5 } from './section5.jsx';
export { default as Section6 } from './section6.jsx';